import sys, tempfile, unittest, json, shutil
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'runtime'))
from verify_manifest import verify
class VerifyManifestTests(unittest.TestCase):
    def test_real_manifest(self):
        self.assertEqual(verify(BASE)['verdict'],'BYTE_INTEGRITY_PASS_UNAUTHENTICATED')
    def test_nested_manifest_is_covered(self):
        entries=verify(BASE)
        self.assertEqual(entries['verdict'],'BYTE_INTEGRITY_PASS_UNAUTHENTICATED')
        self.assertIn('components/v0_5/SHA256_MANIFEST.json', __import__('json').loads((BASE/'SHA256_MANIFEST.json').read_text())['files'])
    def test_tampered_file(self):
        with tempfile.TemporaryDirectory() as t:
            dst=Path(t)
            shutil.copy2(BASE/'SHA256_MANIFEST.json',dst/'SHA256_MANIFEST.json')
            (dst/'README.md').write_text('not authentic')
            result=verify(dst)
            self.assertEqual(result['verdict'],'BYTE_INTEGRITY_FAILED')
            self.assertTrue(result['missing'])
            self.assertIn('README.md',result['changed'])
if __name__=='__main__':unittest.main()
