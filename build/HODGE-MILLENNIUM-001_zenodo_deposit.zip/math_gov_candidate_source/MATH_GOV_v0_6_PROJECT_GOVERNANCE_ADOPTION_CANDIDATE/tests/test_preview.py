import copy
import json
import subprocess
import sys
import unittest
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'runtime'))
from governance_preview import Invalid, read_json, validate_state, validate_plan, plan, capsule, report, unique_pairs

class GovernancePreviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.state=read_json(BASE/'governance/PROJECT_STATE.yaml')
        cls.demo=read_json(BASE/'examples/ten_tasks.json')
    def test_template_no_go(self):
        self.assertEqual(validate_state(self.state)['verdict'],'NO_GO_UNBOUND')
    def test_template_never_release(self):
        self.assertFalse(validate_state(self.state)['release_authorized'])
    def test_claiming_active_state_blocks(self):
        s=copy.deepcopy(self.state);s['status']='LIVE';self.assertNotEqual(validate_state(s)['errors'],[])
    def test_new_claimed_release_blocks(self):
        s=copy.deepcopy(self.state);s['release_authorized']=True;self.assertNotEqual(validate_state(s)['errors'],[])
    def test_invented_host_blocks(self):
        s=copy.deepcopy(self.state);s['external_host']['authenticated']=True;self.assertNotEqual(validate_state(s)['errors'],[])
    def test_extra_authority_blocks(self):
        s=copy.deepcopy(self.state);s['authority_files'].append('governance/FOURTH.md');self.assertNotEqual(validate_state(s)['errors'],[])
    def test_all_gates_unsupported(self):
        s=copy.deepcopy(self.state);s['hard_gates']['G6']='PASS';self.assertNotEqual(validate_state(s)['errors'],[])
    def test_demo_valid(self):self.assertFalse(validate_plan(self.demo)[0])
    def test_five_out_of_ten(self):
        r=report(self.demo);self.assertEqual(r['tasks_executed_or_submitted'],5)
        self.assertEqual(r['theorem_progress'],'UNKNOWN')
    def test_two_submitted(self):self.assertEqual(report(self.demo)['tasks_submitted_pending_review'],2)
    def test_two_steps_with_obligations(self):self.assertEqual(report(self.demo)['steps_with_recorded_open_obligations'],2)
    def test_never_lean_verified_from_count(self):self.assertEqual(report(self.demo)['formal_proofs_verified'],0)
    def test_capsule_blocked(self):self.assertEqual(capsule(self.demo,'T06')['verdict'],'INCOMPLETE_CONTEXT_CAPSULE_NOT_DISPATCHABLE')
    def test_missing_capsule_source_flagged(self):self.assertIn('approved target full text',capsule(self.demo,'T01')['missing'])
    def test_invalid_capsule_task(self):self.assertEqual(capsule(self.demo,'NO_TASK')['verdict'],'BLOCKED')
    def test_planner_does_not_accept_worker_claim(self):
        d=copy.deepcopy(self.demo);d['verified_task_receipts']=['fake'];self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_lean_receipts_do_not_authenticate(self):
        d=copy.deepcopy(self.demo);d['lean_receipts']=[{'fake':'PASS'}];self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_strong_step_verification_not_authentic(self):
        d=copy.deepcopy(self.demo);d['steps'][0]['status']='ACCEPTED_STEP';self.assertEqual(report(d)['verdict'],'BLOCKED')
    def test_provenance_digest_format(self):
        d=copy.deepcopy(self.demo);d['original_question_digest']='FAKE';self.assertEqual(report(d)['verdict'],'BLOCKED')
    def test_duplicate_task_rejected(self):
        d=copy.deepcopy(self.demo);d['tasks'][1]['id']='T01';self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_missing_branch_rejected(self):
        d=copy.deepcopy(self.demo);d['tasks'][0]['branch']='OTHER';self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_missing_step_rejected(self):
        d=copy.deepcopy(self.demo);d['steps']=d['steps'][1:];self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_orphan_step_rejected(self):
        d=copy.deepcopy(self.demo);d['steps'].append({'id':'S99','status':'PROPOSED'});self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_cycle_rejected(self):
        d=copy.deepcopy(self.demo);d['tasks'][0]['deps_all']=['T10'];self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_unknown_dependency_rejected(self):
        d=copy.deepcopy(self.demo);d['tasks'][0]['deps_all']=['T99'];self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_bad_or_group_rejected(self):
        d=copy.deepcopy(self.demo);d['tasks'][8]['deps_any']=[[]]
        with self.assertRaises(Invalid):validate_plan(d)
    def test_task_accepted_without_receipt_rejected(self):
        d=copy.deepcopy(self.demo);d['tasks'][0]['state']='ACCEPTED_TASK';self.assertEqual(plan(d)['verdict'],'BLOCKED')
    def test_linkage_no_cross_branch_transfer(self):self.assertTrue(capsule(self.demo,'T06')['no_unauthorized_cross_branch_data'])
    def test_strong_claim_blocked(self):
        d=copy.deepcopy(self.demo);d['claims']=[{'text':'RH proved'}];self.assertEqual(report(d)['verdict'],'BLOCKED')
    def test_double_json_keys_rejected(self):
        with self.assertRaises(Invalid):json.loads('{"a":1,"a":2}',object_pairs_hook=unique_pairs)
    def test_malformed_plan_blocks(self):
        with self.assertRaises(Invalid):validate_plan({'branches':{},'tasks':[],'steps':[]})
    def test_every_plan_is_non_authoritative(self):self.assertFalse(plan(self.demo)['release_authorized'])
    def test_t06_dependencies_unverified(self):
        r=plan(self.demo);t=next(x for x in r['tasks'] if x['task_id']=='T06');self.assertEqual(t['dispatch_preview'],'DEPENDENCIES_NOT_AUTHENTICATED')
    def test_t07_dependency_unverified(self):
        r=plan(self.demo);t=next(x for x in r['tasks'] if x['task_id']=='T07');self.assertEqual(t['dispatch_preview'],'DEPENDENCIES_NOT_AUTHENTICATED')
    def test_t09_or_alternatives_unverified(self):
        r=plan(self.demo);t=next(x for x in r['tasks'] if x['task_id']=='T09');self.assertEqual(t['dispatch_preview'],'DEPENDENCIES_NOT_AUTHENTICATED')
    def test_full_cli_malformed_fails_closed(self):
        result=subprocess.run([sys.executable,str(BASE/'runtime/governance_preview.py'),'plan',str(BASE/'README.md')],capture_output=True,text=True)
        self.assertEqual(result.returncode,2);self.assertIn('BLOCKED',result.stdout)

if __name__=='__main__':unittest.main()
