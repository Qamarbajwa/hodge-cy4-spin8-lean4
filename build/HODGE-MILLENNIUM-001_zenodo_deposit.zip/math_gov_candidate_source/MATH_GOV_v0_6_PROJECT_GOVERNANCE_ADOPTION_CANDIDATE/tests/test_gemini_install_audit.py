import tempfile, json, unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'))
sys.path.insert(0,str(ROOT/'deployment/gemini_cli/hooks'))
from gemini_install_audit import audit
from deny_mutations import decide

class GeminiInstallAuditTests(unittest.TestCase):
    def fixture(self,root):
        (root/'governance').mkdir()
        for filename in ('GOVERNANCE.md','PROJECT_DIRECTION.md','PROJECT_STATE.yaml'):
            (root/'governance'/filename).write_text('candidate only')
        (root/'GEMINI.md').write_text('advisory')
        (root/'.gemini').mkdir()
        (root/'.gemini/settings.json').write_text(json.dumps({'hooksConfig':{'enabled':True},'hooks':{'BeforeTool':[{'matcher':'.*','hooks':[{'name':'guard','type':'command','command':'/path/guard.py'}]}]}}))
    def test_absent_root_fails(self):
        self.assertEqual(audit(Path('/this/does/not/exist'),'cli')['release_authorized'],False)
    def test_no_files_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertNotEqual(audit(Path(d),'cli')['missing'],[])
    def test_cli_candidate_never_release(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(Path(d));r=audit(Path(d),'cli')
            self.assertEqual(r['verdict'],'CANDIDATE_FILES_PRESENT_EXTERNAL_VERIFICATION_REQUIRED')
            self.assertFalse(r['release_authorized'])
            self.assertFalse(r['independent_acceptance'])
    def test_missing_authority_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);(root/'governance/PROJECT_DIRECTION.md').unlink()
            self.assertIn('governance/PROJECT_DIRECTION.md',audit(root,'cli')['missing'])
    def test_hooks_disabled_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root)
            (root/'.gemini/settings.json').write_text(json.dumps({'hooksConfig':{'enabled':False},'hooks':{'BeforeTool':[{'hooks':[{'command':'hi'}]}]}}))
            self.assertIn('hooks disabled or uncertain',audit(root,'cli')['missing'])
    def test_missing_beforetool_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);(root/'.gemini/settings.json').write_text('{}')
            self.assertIn('BeforeTool configuration absent',audit(root,'cli')['missing'])
    def test_bad_settings_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root);(root/'.gemini/settings.json').write_text('{')
            self.assertIn('Gemini settings malformed',audit(root,'cli')['missing'])
    def test_chat_cannot_claim_file_enforcement(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root)
            self.assertNotEqual(audit(root,'chat')['missing'],[])
    def test_adk_needs_callback_attestations(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.fixture(root)
            self.assertIn('ADK external callback and tool-grant attestations unavailable to local scanner',audit(root,'adk')['missing'])
    def test_hook_read(self):self.assertTrue(decide({'tool_name':'read_file','tool_input':{'file_path':'x'}})[0])
    def test_hook_write(self):self.assertFalse(decide({'tool_name':'write_file','tool_input':{'file_path':'x'}})[0])
    def test_hook_shell(self):self.assertFalse(decide({'tool_name':'run_shell_command','tool_input':{'command':'echo x'}})[0])
    def test_hook_unknown(self):self.assertFalse(decide({'tool_name':'mcp_unknown','tool_input':{}})[0])
    def test_hook_missing_payload(self):self.assertFalse(decide({})[0])
    def test_hook_malformed_args(self):self.assertFalse(decide({'tool_name':'read_file','tool_input':'x'})[0])

if __name__=='__main__':unittest.main()
