import copy
import json
import pathlib
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import math_step_engine as e
import lean_step_runner as l
import event_ledger as ev
CASE=json.loads((ROOT/'examples/demo_case.json').read_text())
ORIGINAL=CASE['original']['digest']
FORMAL=CASE['formal_target']['digest']
CONTRACT=e.digest(e.canonical({'required_inventory':CASE['required_inventory'],'required_edges':CASE['required_edges']}))
BASELINE=e.digest(e.canonical(CASE))

def mutate_node(case,id): return next(x for x in case['nodes'] if x['id']==id)

class StructuralTests(unittest.TestCase):
    def base(self): return copy.deepcopy(CASE)
    def audit(self,c, o=ORIGINAL, f=FORMAL): return e.audit(c,o,f,CONTRACT)
    def blocks(self,c,match):
        result=self.audit(c)
        self.assertEqual(result['verdict'],'BLOCKED', result)
        self.assertIn(match,' '.join(result['errors']))

    def test_baseline_structure(self): self.assertEqual(self.audit(self.base())['verdict'],'STRUCTURAL_PREFLIGHT_PASS_ONLY')
    def test_no_release_on_pass(self): self.assertFalse(self.audit(self.base())['release_authorized'])
    def test_missing_external_original_anchor(self): self.assertIn('original-question digest',' '.join(e.audit(self.base())['errors']))
    def test_missing_formal_anchor(self): self.assertIn('formal target digest',' '.join(e.audit(self.base(),ORIGINAL)['errors']))
    def test_original_changed_and_self_rehashed(self):
        c=self.base(); c['original']['text']='The Riemann hypothesis is proven.'; c['original']['digest']=e.digest(c['original']['text']);self.blocks(c,'owner-anchored')
    def test_formal_goal_weakening_self_rehashed(self):
        c=self.base(); c['formal_target']['statement']='True'; c['formal_target']['digest']=e.digest('True');self.blocks(c,'approved digest')
    def test_missing_mathematical_step(self):
        c=self.base(); c['nodes']=[x for x in c['nodes'] if x['id']!='S1'];self.blocks(c,'INVENTORY: missing S1')
    def test_missing_edge(self):
        c=self.base(); c['edges']=[x for x in c['edges'] if not (x['source']=='S1' and x['target']=='S2')];self.blocks(c,'required edge missing')
    def test_missing_all_required_edge_registry(self):
        c=self.base(); del c['required_edges'];self.blocks(c,'missing independent required edge inventory')
    def test_undeclared_premise(self):
        c=self.base(); mutate_node(c,'S2')['premises'].append('SRC-ORIGINAL');self.blocks(c,'absent from dependency graph')
    def test_fake_formal_checked_status_rejected(self):
        c=self.base(); mutate_node(c,'S1')['state']='FORMALLY_CHECKED';self.blocks(c,'self-asserted formal verification')
    def test_unclosed_formal_candidate(self):
        c=self.base(); mutate_node(c,'S1')['state']='FORMAL_CANDIDATE';self.blocks(c,'open obligations')
    def test_discharge_unknown_obligation(self):
        c=self.base(); mutate_node(c,'S1')['discharged']=['ghost'];self.blocks(c,'not in declared obligations')
    def test_duplicate_obligation_rejected(self):
        c=self.base(); mutate_node(c,'S1')['obligations']=['x','x'];self.blocks(c,'duplicate proof obligations')
    def test_task_self_acceptance_rejected(self):
        c=self.base(); mutate_node(c,'T1')['state']='TASK_ACCEPTED';self.blocks(c,'untrusted task acceptance')
    def test_strong_claim_self_report_rejected(self):
        c=self.base(); mutate_node(c,'C1')['reported_strength']='THEOREM_PROVED';self.blocks(c,'cannot be self-declared')
    def test_claim_evidence_link_removed(self):
        c=self.base(); c['edges']=[x for x in c['edges'] if x['target']!='C1'];self.blocks(c,'required edge missing')
    def test_graph_self_cycle(self):
        c=self.base(); c['edges'].append({'source':'T1','target':'T1','kind':'AND'});self.blocks(c,'self-edge')
    def test_graph_two_node_cycle(self):
        c=self.base(); c['edges'].append({'source':'T2','target':'T1','kind':'AND'});self.blocks(c,'cycle')
    def test_reject_cross_branch(self):
        c=self.base(); c['edges'].append({'source':'T2','target':'T3','kind':'AND'});self.blocks(c,'unauthorized cross-branch')
    def test_unregistered_node(self):
        c=self.base(); c['nodes'].append({'id':'GHOST','kind':'CLAIM','reported_strength':'DRAFT_CLAIM','evidence_refs':['S1']});self.blocks(c,'unregistered node')
    def test_missing_step_owner(self):
        c=self.base(); mutate_node(c,'S2')['task_id']='GHOST';self.blocks(c,'missing owning TASK')
    def test_wrong_lean_digest(self):
        c=self.base(); mutate_node(c,'S1')['lean']['statement_digest']='0'*64;self.blocks(c,'Lean formal statement digest mismatch')
    def test_malformed_root(self): self.assertEqual(e.audit(None)['verdict'],'BLOCKED')
    def test_malformed_premises_is_blocked(self):
        c=self.base(); mutate_node(c,'S1')['premises']=42;self.blocks(c,'premises not array')
    def test_malformed_obligations_is_blocked(self):
        c=self.base(); mutate_node(c,'S1')['obligations']=None;self.blocks(c,'invalid proof obligations')
    def test_impacted_descendants_source_change(self):
        c=self.base();n=mutate_node(c,'SRC-DEFS');n['content']='different';n['content_digest']=e.digest('different')
        result=e.impact(CASE,c,BASELINE)
        self.assertEqual(result['verdict'],'IMPACT_REPORT_NOT_APPLIED',result)
        self.assertTrue({'SRC-DEFS','S1','T1','S2','T2','C1','D1','P1'}.issubset(result['must_revalidate']))
    def test_unrelated_branch_not_overinvalidated(self):
        c=self.base();n=mutate_node(c,'S2');n['goal']='other';n['goal_digest']=e.digest('other')
        result=e.impact(CASE,c,BASELINE)
        self.assertNotIn('T3',result['must_revalidate'])
    def test_root_change_invalidates_all(self):
        c=self.base();c['original']['text']='changed';c['original']['digest']=e.digest('changed')
        result=e.impact(CASE,c,BASELINE)
        self.assertEqual(set(result['must_revalidate']),set(CASE['required_inventory']))
    def test_diff_anchor_mismatch_blocked(self):
        self.assertEqual(e.impact(CASE,CASE,'0'*64)['verdict'],'BLOCKED')
    def test_required_original_in_capsule(self):
        r=e.task_readiness(CASE,'T2',['T1']);self.assertEqual(r['dispatch'],'STRUCTURALLY_READY_HOST_GRANT_REQUIRED');self.assertEqual(r['original_digest'],ORIGINAL)
    def test_missing_dependencies_blocks_dispatch(self):
        self.assertEqual(e.task_readiness(CASE,'T2')['dispatch'],'BLOCKED_DEPENDENCIES')
    def test_task_cannot_self_advance(self):
        c=self.base(); mutate_node(c,'T1')['state']='TASK_ACCEPTED';self.assertEqual(e.task_readiness(c,'T2')['dispatch'],'BLOCKED')
    def test_or_group_requires_one(self):
        c=self.base(); c['nodes'].append({'id':'T4','kind':'TASK','purpose':'RESEARCH','state':'PLANNED','branch':'ROOT','step_ids':[]});c['required_inventory'].append('T4')
        edge={'source':'T4','target':'T2','kind':'OR','group':'alternatives'};c['edges'].append(edge);c['required_edges'].append(edge)
        self.assertEqual(e.task_readiness(c,'T2',['T1'])['dispatch'],'BLOCKED_DEPENDENCIES')
        self.assertEqual(e.task_readiness(c,'T2',['T1','T4'])['dispatch'],'STRUCTURALLY_READY_HOST_GRANT_REQUIRED')
    def test_progress_no_percentage(self):
        out=e.progress(CASE);self.assertEqual(out['tasks_execution_finished'],1);self.assertEqual(out['theorem_progress_percent'],'UNKNOWN');self.assertFalse(out['proof_verified'])

class LeanTests(unittest.TestCase):
    def test_axioms_clean(self):self.assertEqual(l.extract_axioms('MathGov.step1 does not depend on any axioms','MathGov.step1'),[])
    def test_axioms_sorry(self):self.assertEqual(l.extract_axioms('MathGov.step1 depends on axioms: [sorryAx]','MathGov.step1'),['sorryAx'])
    def test_axioms_unknown(self):self.assertIsNone(l.extract_axioms('my unrelated proof compiled','MathGov.step1'))
    def test_path_traversal(self):
        self.assertEqual(l.check_step(ROOT,'../evil.lean','MathGov.step1','True','0'*64)['verdict'],'SOURCE_PATH_DENIED')
    def test_unpinned_project(self):
        path=ROOT/'examples/ProofSteps.lean';self.assertEqual(l.check_step(ROOT,'examples/ProofSteps.lean','MathGov.step1','True',l.sha(path.read_bytes()))['verdict'],'UNPINNED_LEAN_PROJECT')
    def test_bad_source_digest(self):
        self.assertEqual(l.check_step(ROOT,'examples/ProofSteps.lean','MathGov.step1','True','0'*64)['verdict'],'STALE_OR_CHANGED_SOURCE')
    def test_missing_lean_if_pinned(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);(root/'Proof.lean').write_text('theorem a : True := trivial');(root/'lean-toolchain').write_text('test');(root/'lakefile.toml').write_text('name = "x"');(root/'lake-manifest.json').write_text('{}')
            with patch.object(l.shutil,'which',return_value=None):
                r=l.check_step(root,'Proof.lean','a','True',l.sha((root/'Proof.lean').read_bytes()))
            self.assertEqual(r['verdict'],'LEAN_UNAVAILABLE')
    def test_simulated_clean_command_does_not_authorize_release(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);(root/'Proof.lean').write_text('theorem a : True := trivial');(root/'lean-toolchain').write_text('test');(root/'lakefile.toml').write_text('name = "x"');(root/'lake-manifest.json').write_text('{}')
            with patch.object(l.shutil,'which',return_value='/fake/lake'),patch.object(l.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='a does not depend on any axioms',stderr='')):
                r=l.check_step(root,'Proof.lean','a','True',l.sha((root/'Proof.lean').read_bytes()))
            self.assertEqual(r['verdict'],'LOCAL_LEAN_STEP_CHECK_PASS_PENDING_INDEPENDENT_RECHECK')
            self.assertFalse(r['release_authorized']); self.assertFalse(r['proof_complete'])
    def test_simulated_sorry_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            root=pathlib.Path(t);(root/'Proof.lean').write_text('theorem a : True := by sorry');(root/'lean-toolchain').write_text('test');(root/'lakefile.toml').write_text('name = "x"');(root/'lake-manifest.json').write_text('{}')
            with patch.object(l.shutil,'which',return_value='/fake/lake'),patch.object(l.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='a depends on axioms: [sorryAx]',stderr='')):
                r=l.check_step(root,'Proof.lean','a','True',l.sha((root/'Proof.lean').read_bytes()))
            self.assertEqual(r['verdict'],'DISALLOWED_AXIOMS')

class LedgerTests(unittest.TestCase):
    def setUp(self):self.conn=sqlite3.connect(':memory:');ev.init(self.conn)
    def test_exact_binary_roundtrip(self):
        p=b'prompt\x00\xff \n';o=b'response\x00\xc3\xa9';ev.append(self.conn,'PROMPT_RESULT','worker1','S1',p,o)
        stored=json.loads(self.conn.execute('select event from events').fetchone()[0]);self.assertEqual(ev.verify_bytes(stored['prompt']),p);self.assertEqual(ev.verify_bytes(stored['result']),o)
    def test_chain_verification(self):
        ev.append(self.conn,'PROMPT_RESULT','worker','S1',b'one',b'two');self.assertEqual(ev.verify(self.conn)['verdict'],'LOCAL_CHAIN_VALID_UNAUTHENTICATED')
    def test_tamper_detection(self):
        ev.append(self.conn,'PROMPT_RESULT','worker','S1',b'one',b'two')
        self.conn.execute('update events set event=? where seq=1',('{}',));self.conn.commit()
        self.assertIn(ev.verify(self.conn)['verdict'],('TAMPER_DETECTED','TAMPER_OR_INVALID_EVENT'))
    def test_truncated_ledger_detected_with_count(self):
        ev.append(self.conn,'PROMPT_RESULT','worker','S1',b'one',b'two');self.conn.execute('delete from events');self.conn.commit()
        self.assertEqual(ev.verify(self.conn,expected_count=1)['verdict'],'EVENT_COUNT_MISMATCH')
    def test_external_anchor_mismatch(self):
        ev.append(self.conn,'PROMPT_RESULT','worker','S1',b'one',b'two')
        self.assertEqual(ev.verify(self.conn,externally_anchored_head='0'*64)['verdict'],'EXTERNAL_ANCHOR_MISMATCH')

if __name__=='__main__': unittest.main()

class IntegratedStepVerificationTests(unittest.TestCase):
    def test_real_runner_invocation_fails_when_lean_project_unpinned(self):
        import step_verifier as sv
        case=copy.deepcopy(CASE);step=mutate_node(case,'S1')
        out=sv.check_formal_step(case,'S1',ROOT,'examples/ProofSteps.lean',ORIGINAL,FORMAL,
                                 step['goal_digest'],step['lean']['source_digest'],CONTRACT)
        self.assertEqual(out['verdict'],'BLOCKED');self.assertEqual(out['reason'],'LEAN_CHECK_FAILED_OR_NOT_AVAILABLE')
        self.assertFalse(out['proof_verified'])
    def test_step_cannot_fabricate_goal_binding(self):
        import step_verifier as sv
        case=copy.deepcopy(CASE);step=mutate_node(case,'S1')
        out=sv.check_formal_step(case,'S1',ROOT,'examples/ProofSteps.lean',ORIGINAL,FORMAL,'0'*64,step['lean']['source_digest'],CONTRACT)
        self.assertEqual(out['reason'],'STEP_GOAL_ANCHOR_MISMATCH')
    def test_step_cannot_fabricate_source_binding(self):
        import step_verifier as sv
        case=copy.deepcopy(CASE);step=mutate_node(case,'S1')
        out=sv.check_formal_step(case,'S1',ROOT,'examples/ProofSteps.lean',ORIGINAL,FORMAL,step['goal_digest'],'0'*64,CONTRACT)
        self.assertEqual(out['reason'],'STEP_LEAN_SOURCE_ANCHOR_MISMATCH')
    def test_worker_cannot_claim_lean_verified(self):
        import step_verifier as sv
        case=copy.deepcopy(CASE);step=mutate_node(case,'S1');step['state']='FORMALLY_CHECKED'
        out=sv.check_formal_step(case,'S1',ROOT,'examples/ProofSteps.lean',ORIGINAL,FORMAL,step['goal_digest'],step['lean']['source_digest'],CONTRACT)
        self.assertEqual(out['reason'],'STRUCTURAL_OR_SOURCE_ANCHOR_FAILURE')

class RecoveryAndExampleTests(unittest.TestCase):
    def test_five_of_ten_is_not_half_proof(self):
        case=json.loads((ROOT/'examples/five_of_ten.json').read_text())
        out=e.progress(case);self.assertEqual(out['tasks_total'],10);self.assertEqual(out['tasks_execution_finished'],5)
        self.assertEqual(out['theorem_progress_percent'],'UNKNOWN');self.assertFalse(out['proof_verified'])
    def test_malformed_impact_cannot_throw(self):
        c=copy.deepcopy(CASE);c['nodes'][0]['id']=['not_hashable']
        self.assertEqual(e.impact(CASE,c,BASELINE)['verdict'],'BLOCKED')
    def test_missing_dependency_report_is_not_artifact_approval(self):
        case=json.loads((ROOT/'examples/five_of_ten.json').read_text())
        self.assertEqual(e.task_readiness(case,'T6')['dispatch'],'BLOCKED_DEPENDENCIES')
        self.assertEqual(e.task_readiness(case,'T6',['T5'])['dispatch'],'STRUCTURALLY_READY_HOST_GRANT_REQUIRED')
    def test_ledger_invalid_base64_blocked(self):
        conn=sqlite3.connect(':memory:');ev.init(conn)
        ev.append(conn,'PROMPT_RESULT','worker','S1',b'x',b'y')
        obj=json.loads(conn.execute('select event from events').fetchone()[0]);obj['prompt']['base64']='***'
        conn.execute('update events set event=? where seq=1',(json.dumps(obj),));conn.commit()
        self.assertEqual(ev.verify(conn)['verdict'],'TAMPER_OR_INVALID_EVENT')
