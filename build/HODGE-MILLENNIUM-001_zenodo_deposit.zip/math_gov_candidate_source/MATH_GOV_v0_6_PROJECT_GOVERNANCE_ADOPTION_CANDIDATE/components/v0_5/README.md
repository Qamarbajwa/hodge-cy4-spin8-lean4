# MATH-GOV v0.5 — Step and Proof Obligation Engine (experimental candidate)

**Status: NOT PROMOTED / NO PRODUCTION RELEASE / NO THEOREM VERIFIED.** The candidate repairs meaningful structural issues raised in MATH-GOV stepwise reviews. It does not install or deploy Lean, authenticate the owner's mathematical intent, run independent reviewers, secure the host operating system, or modify the three canonical Governance OS authority files.

## Implemented here

- `math_step_engine.py`: checks original-question/formal-target digests against separately supplied anchors; verifies a complete typed node/edge inventory; checks step goals, ownership, explicit premises, subgoal records, and DAGs; rejects self-declared mathematical proof / task acceptance; produces derived changes and descendant invalidation; provides structural task readiness and partial-progress reporting. The inventory and edge contract also requires a separately supplied, immutable digest. It **cannot** independently know which mathematical dependencies were omitted unless the authoritative inventory is independently reviewed and pinned.
- `step_verifier.py`: joins the structural preflight to local Lean execution, refusing changed source or step goal. An actual check cannot succeed without a real Lean environment.
- `lean_step_runner.py`: checks pinned file digest; requires a Lean Lake project, version pin, and manifest; builds a verification wrapper with a separately supplied exact target and `#print axioms`, rejects warnings/errors/disallowed axioms. Its output parsing is only a preflight, not a security-proof checker. Even a successful local run is `LOCAL_LEAN_STEP_CHECK_PASS_PENDING_INDEPENDENT_RECHECK`, **not** a theorem-verified/accepted state. **Lean code must run in an external isolated environment; this script is not a sandbox.**
- `event_ledger.py`: SQLite-serialized, hash-linked records preserving the exact bytes of prompts and results. A separate trusted anchor is necessary to detect whole-ledger replacement, and access controls remain external. Tool calls and source edits should be captured as their own event types.
- `examples/`: proposed Lean code, example step/claim graph, 5/10 execution fixture and example goals.
- `tests/`: positive, negative and adversarial local tests, including mocked command results. Mocked Lean checks are **not real theorem proofs**.

## Reproduce local tests

```bash
cd MATH_GOV_v0_5_STEP_PROOF_ENGINE_CANDIDATE
python -m unittest discover -s tests -v
python math_step_engine.py progress examples/five_of_ten.json
```

Validate the sample against **separately recorded** digests:

```bash
python math_step_engine.py audit examples/demo_case.json \
  --original-digest 04624f81ccf2ef98cbd91ba8f382de243631db1af5920d1174315596b45c0520 \
  --formal-digest bdb47f9dc7199f64b3dcbfb6c8ea221346ded339b5edc51c86f2e81755cbc675 \
  --contract-digest e0f097d4c52c31ad699c6bd16e695b2f1b91b88057e6318392dcdebc29284980
```

## Running an ACTUAL Lean step check on a trusted, isolated machine

1. Install the official `elan`/`lake`/`lean` toolchain in a sandbox with untrusted-source restrictions and no secrets. This environment did **not** contain Lean.
2. In `examples/LeanDemoProject/`, run `lake update` (to create a real manifest) and `lake build` under your pinned toolchain.
3. Read the values in `examples/BASELINE_HASHES.json`. Confirm them from the independent frozen owner/goal contract, **not solely from the worker's JSON**.
4. Run `step_verifier.py` from the candidate root, supplying your project and independently pinned digests:

```bash
python step_verifier.py examples/demo_case.json S1 \
  examples/LeanDemoProject ProofSteps.lean \
  --original-digest 04624f81ccf2ef98cbd91ba8f382de243631db1af5920d1174315596b45c0520 \
  --formal-digest bdb47f9dc7199f64b3dcbfb6c8ea221346ded339b5edc51c86f2e81755cbc675 \
  --step-goal-digest bdb47f9dc7199f64b3dcbfb6c8ea221346ded339b5edc51c86f2e81755cbc675 \
  --source-digest ffa82a454a30a804a9906335ee5b5a2312c1780eb7a4852675 \
  --contract-digest e0f097d4c52c31ad699c6bd16e695b2f1b91b88057e6318392dcdebc29284980
```

5. For stronger checking use Lean 4.35+ `lake check --paranoid`, where the isolated host supports it. Use `lake comparator` with a **separately maintained** challenge/solution pair to audit the formal target's identity. Consult your installed release's command help; this candidate does not execute these acceptance tools automatically.
6. Independently verify the meaning of the formal statement against the human research question, including domains, notation, definitions, axioms, and implicit assumptions. Preserve exact authenticated execution logs and approvals.

## What 5 out of 10 tasks means

`python math_step_engine.py progress examples/five_of_ten.json` reports **5 tasks finished execution, 2 steps with open obligations, theorem progress UNKNOWN, and proof_verified FALSE**. It never reports “50% of a theorem proved.”

## Approval levels

1. `PROPOSED` or `FORMAL_CANDIDATE`: agent-authored artifact, not verified.
2. `LOCAL_LEAN_STEP_CHECK_PASS_PENDING_INDEPENDENT_RECHECK`: checked by a local process with pinned file and explicit goal, subject to its host's trust boundary. Not proof acceptance.
3. Independent replay + axiom validation + formal-target comparison + semantic audit: **not implemented as an authenticated approval service in this candidate**.
4. Accepted theorem/publication statement: requires external qualified review, independent acceptor and record-backed authority. Not possible through this package alone.

## Important boundaries

- This package is a modular research prototype, not a replacement for Governance OS canonical authority.
- It cannot ensure completeness of a misleading initial research blueprint without an independently audited specification and dependency inventory.
- Strong mathematical claims still require human review; Lean acceptance alone cannot validate English/formal meaning correspondence.
- Real Gemini integration and supervisor/watchdog orchestration require a trusted host, scoped identity and permissions, reliable source registry, and context retriever.
- The event ledger lacks secure remote anchoring, identity attestation, trusted timestamping and automated capture; it only preserves data explicitly written into it.
- The Lean adapter requires a genuine installed Lean toolchain and an externally enforced isolated execution environment; neither was available here.
