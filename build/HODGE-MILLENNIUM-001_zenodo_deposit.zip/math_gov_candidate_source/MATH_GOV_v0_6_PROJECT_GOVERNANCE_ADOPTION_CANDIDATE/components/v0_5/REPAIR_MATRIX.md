# Stepwise governance gap resolution matrix — 2026-11-10

**Status language:** `IMPLEMENTED_STRUCTURAL` means local Python controls have been tested, not that end-to-end host security or proof correctness has been established; `PARTIAL` means a component exists but a required verified runtime/authority is missing; `OPEN` means it is not implemented here.

| Gap | Resolution in v0.5 | Status |
|---|---|---|
| SW-01 step-level registry | Typed STEP records, owner TASK and mathematical goals | IMPLEMENTED_STRUCTURAL |
| SW-02 inference validity | Explicit premise/justification references and real Lean wrapper when available; nonformal inference audit not supplied | PARTIAL |
| SW-03 original meaning | Separate externally pinned question and target digests; no live owner authentication | PARTIAL |
| SW-04 task vs theorem status | Task, step and claims distinguished; strong self-reported claims rejected | IMPLEMENTED_STRUCTURAL |
| SW-05 authenticated receipts | Local event chain; separate external signer/host anchor required | PARTIAL |
| SW-06 change invalidation | Source diff and transitive impact across original graph and revised graph | IMPLEMENTED_STRUCTURAL |
| SW-07 open subgoals | Explicit obligations; formal candidates with unmatched declared obligations rejected | IMPLEMENTED_STRUCTURAL |
| SW-08 circularity | DAG and premise-linked graph checks | IMPLEMENTED_STRUCTURAL |
| SW-09 Lean trust | Local compile/axiom audit adapter; no real Lean available; comparator/rechecker acceptance not integrated | PARTIAL |
| SW-10 context completeness | Step-specific ready-for-fetch capsule; host retrieval and recall test not implemented | PARTIAL |
| SW-11 branches/alternatives | AND / OR / OPTIONAL / REFUTES / ANALOGY typed edges | IMPLEMENTED_STRUCTURAL |
| SW-12 branch isolation | Cross-branch task prerequisite rejection; no OS sandbox or ACL runtime | PARTIAL |
| SW-13 step granularity | Explicit per-step records; no automated decomposition threshold | PARTIAL |
| SW-14 model capability | Proposed in v0.3; not integrated into verified host | OPEN |
| SW-15 subject focus | Original and formal-goal hash pins; no semantic drift classifier | PARTIAL |
| SW-16 concurrent CAS | No authenticated lease or atomic multi-actor state writer | OPEN |
| SW-17 resume | Byte-preserving ledger and illustrative context capsule; no full trusted checkpoint/recovery | PARTIAL |
| SW-18 independent authority | Separate gate required, but not authenticated in this prototype | OPEN |
| SW-19 false progress | 5/10 fixture reports execution count, theorem progress UNKNOWN | IMPLEMENTED_STRUCTURAL |
| SW-20 failure isolation | Graph reachability invalidates relevant descendants (conservative across optional links) | IMPLEMENTED_STRUCTURAL |
| SW-21 malformed input | Python structural audit and diff fail closed on tested malformed cases | IMPLEMENTED_STRUCTURAL |
| SW-22 publication trace | CLAIM → DIAGRAM → PUBLICATION edges and impact tracking | IMPLEMENTED_STRUCTURAL |

## Follow-on host work (hard gates)

1. Trusted independent owner question/statement archive and externally anchored graph inventory.
2. Permissioned supervisor and worker runtime, branch isolation, source snapshotter, CAS/lease and watchdog.
3. Trusted isolated Lean toolchain, `lake check`, challenge/solution `lake comparator`, reproducible execution receipts.
4. Independent mathematical semantic review and separate acceptor; no agent self-certification.
5. Full adversarial replay against v0.1–v0.4 cases and real Gemini conversations; no simulated PASS promoted to genuine proof validity.
6. Robust context provenance, intuition handling, cross-project relationship registry, and source-linked knowledge retrieval from earlier candidate modules.
