# How Lean checks steps under MATH-GOV

## Separate four meanings of “step”

1. **Intuitive or informal step**: a researcher states a deduction in prose. Governance records it but Lean does not directly know whether the prose is valid.
2. **Mathematical inference step**: exact premises, conclusion and side conditions are specified. MATH-GOV registers explicit obligations, which may be translated into a Lean proposition.
3. **Lean tactic step**: a tactic transforms proof goals into zero or more new goals. A tactic running is not itself a certified theorem. The **elaborated proof term** is what Lean's kernel checks when all goals are discharged.
4. **Independent formal lemma step**: MATH-GOV promotes a material reasoning step into a separately named theorem/lemma and checks its statement and proof, then records that it may be used by later theorems (subject to the review state of assumptions and imports).

Do not equate 'tactic ran', 'Lean source compiled', 'Lean theorem passes permitted-axiom checks', 'the human mathematical question was proved', and 'qualified external acceptance'. These have increasingly strong prerequisites.

## Step-acceptance obligations

For each material step `S_i`, capture:

- Exact intended mathematical input proposition(s) and active domain/assumptions.
- Expected output proposition and a human-reviewed mapping into Lean (including quantifiers, notation and definitions).
- Proof obligation ledger: subgoals, side conditions, dependencies and unresolved assumptions.
- Frozen Lean file digest, Lean+Mathlib pin, manifest, theorem name and **separate authoritative target statement**.
- Live Lean compile and kernel result; parse `#print axioms <theorem>` for transitive `sorryAx` and non-approved axioms. This runner accepts only the three standard logical axioms, which is conservative.
- Independent Lean project replay and optionally `lake check --paranoid` / `lake comparator` for Lean 4.35+ in an isolated trusted environment.
- Source/statement equivalence audit; signed independent acceptance recorded by a separately authorized actor.

**Example formal structure**:

```lean
namespace MathGov

theorem step1 (n : Nat) : n + 0 = n := by
  simp

theorem step2 (n : Nat) : n = n + 0 := by
  simpa using (step1 n).symm

end MathGov
```

Each named lemma is a separate formal unit. In a real session the runner should verify both `MathGov.step1` and `MathGov.step2` independently, and the top-level theorem again after all changes. This candidate supplies these proposed files but did not run Lean.

## Why `sorry` and hidden axioms matter

Lean can compile proofs containing `sorry`; this relies on `sorryAx`, including transitively through other lemmas. Only a permitted set of axioms can support an unqualified kernel-verified claim. `#print axioms` is necessary to discover tainted dependencies. Native evaluation and custom axioms may change the trust base, so they are rejected in the strict profile unless the policy explicitly authorizes a different qualified claim.

## Statement identity and misleading theorem names

A declaration named `RiemannHypothesis` could formally mean `True`. A Lean checker would correctly verify a proof of `True`, not establish the Riemann hypothesis. Preserve the question from the human researcher separately, define a challenge statement under independent review, and use `lake comparator` where configured to compare challenge versus solution. Even matching syntactic Lean propositions do not automatically prove that the independent challenge correctly models the original human meaning.

## Limits of this shipped adapter

- The `lean_step_runner.py` subprocess is **not** a security boundary: Lean tactics, macros and imports may execute code. Only use after a trusted sandbox is provided.
- Source hash/manifest/version pins are necessary but not sufficient to authenticate an artifact's publisher or protect against a compromised toolchain.
- Our regex-based axiom report parsing is a local preflight, not an independent proof certificate. For hostile proof artifacts prefer Lean's `lake check` and challenge/comparator workflows in independently controlled infrastructure.
- The current candidate has no installed Lean, no Mathlib checkout, no running verifier service, no formal statement semantic reviewer, and no externally authenticated acceptor. Therefore there is **no actual verified mathematical theorem in this release**.
- The local tests mocking Lean stdout are deliberately labeled synthetic and demonstrate fail-closed integration logic only.

## External references

- https://lean-lang.org/doc/reference/latest/ValidatingProofs/
- https://lean-lang.org/doc/reference/latest/Axioms
- https://lean-lang.org/doc/reference/latest/releases/v4.35.0/
- https://github.com/leanprover-community/leanprover-community.github.io/blob/lean4/templates/did_you_prove_it.md
