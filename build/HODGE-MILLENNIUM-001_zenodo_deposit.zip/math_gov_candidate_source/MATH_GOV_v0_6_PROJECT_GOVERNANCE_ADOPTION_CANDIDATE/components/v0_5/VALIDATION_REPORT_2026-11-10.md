# MATH-GOV v0.5 local validation and release boundary

**Date:** 2026-11-10 (artifact build).  **Verdict:** experimental structural prototype / NO-GO for production mathematical verification.

## Reproduced checks

- `python -m unittest discover -s tests -v`: **57 tests, 57 pass, 0 failures**.
- Independent sample audit using pinned original-question, pinned target, and pinned graph-inventory digests: `STRUCTURAL_PREFLIGHT_PASS_ONLY`. The audit always returns `formal_proof_verified=false` and `release_authorized=false`.
- Sample `five_of_ten.json`: 5 tasks finished execution, 2 steps with open proof obligations, theorem progress `UNKNOWN`, `proof_verified=false`.
- Local `step_verifier.py`: blocked with `UNPINNED_LEAN_PROJECT` because this fresh template does not include a fabricated Lake dependency manifest. The current execution environment has **no installed Lean/Lake executable**.
- Synthetic `unittest.mock` Lean-tool outputs test parser and gate behavior. These are **mocked command responses**, not checked mathematical proof terms.
- Hash-linked prompt/result archive was tested for exact bytes, local edits and external-anchor mismatches; no remotely authenticated writer/anchor is present.

## What was built

1. Typed mathematical STEP/TASK/SOURCE/CLAIM/DIAGRAM/PUBLICATION graph and required-edge inventory.
2. Explicit goal/premise/obligation status validation, blockers for undeclared strong claims, cyclical dependencies and open obligations in formal candidates.
3. Source-derived impact across original and new dependency graphs, including statement revisions, with mandatory pinned baseline snapshot digest.
4. Branch-aware task readiness and 5/10 task reporting without theorem-percentage inventions.
5. `step_verifier.py` -> actual `lean_step_runner.py` executable boundary, with exact goal/source pins, axiom parser and rejection of unapproved axioms. Real Lean is not available here.
6. Exact-byte prompt/result SQLite event ledger with hash chaining, awaiting trusted external identity and anchor.
7. Regenerable Mermaid dependency diagram derived from the test graph.

## Remain NO-GO until independently established

- Real Lean toolchain and isolated runner, actual Lean kernel execution, independent `lake check` and `lake comparator` checks.
- Owner-authenticated question and formal-statement semantics, with independently reviewed required proof-step and dependency completeness.
- Authenticated Gemini ingestion, branch-scoped tool access, supervisor/worker identity, independent watchdog, lease and CAS state writer.
- Complete step/subgoal tracking from a real Lean proof state, not just JSON declared obligations.
- Validated research claim-calibration (overclaim **and** underclaim), independent mathematical review, authenticated release acceptance.
- Full adversarial regression against actual earlier Gemini research projects and v0.1–v0.4 candidate defects.

**Important:** A passing local program test validates the behavior of the tested implementation on the tested inputs. It does not establish the mathematical validity of a new theorem, or deploy/replace canonical Governance OS.
